"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, Package, Settings, Plus, X } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import { getApiUrl, API_CONFIG } from "@/lib/config"

interface InventoryItem {
  _id: string
  itemName: string
  sku: string
  stock: number
  vendor: string
  link?: string
  isAssembledProduct: boolean
  isSupported: boolean
  components?: Array<{
    item: string
    quantity: number
  }>
}

interface NewProduct {
  itemName: string
  sku: string
  vendor: string
  link: string
  isAssembledProduct: boolean
  isSupported: boolean
  components: Array<{
    item: string
    quantity: number
  }>
}

export default function ProductsPage() {
  const [products, setProducts] = useState<InventoryItem[]>([])
  const [complexItems, setComplexItems] = useState<InventoryItem[]>([])
  const [filteredProducts, setFilteredProducts] = useState<InventoryItem[]>([])
  const [filteredComplexItems, setFilteredComplexItems] = useState<InventoryItem[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)
  const [isNewProductOpen, setIsNewProductOpen] = useState(false)
  const [newProduct, setNewProduct] = useState<NewProduct>({
    itemName: "",
    sku: "",
    vendor: "v-armed", // Default vendor to "v-armed"
    link: "",
    isAssembledProduct: false,
    isSupported: true,
    components: [
      { item: "", quantity: 1 },
      { item: "", quantity: 1 },
    ], // Always start with 2 components by default
  })
  const [showNonSupported, setShowNonSupported] = useState(false) // Added state for showing non-supported items
  const [availableComponents, setAvailableComponents] = useState<InventoryItem[]>([]) // Added state for available components
  const { toast } = useToast()

  useEffect(() => {
    fetchProducts()
    fetchAvailableComponents() // Fetch available components on mount
  }, [])

  useEffect(() => {
    const filteredProds = products.filter(
      (product) =>
        product.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.vendor.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    const filteredComplex = complexItems.filter(
      (item) =>
        item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.vendor.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredProducts(filteredProds)
    setFilteredComplexItems(filteredComplex)
  }, [products, complexItems, searchTerm])

  const fetchAvailableComponents = async () => {
    try {
      const itemsResponse = await fetch(getApiUrl(API_CONFIG.ENDPOINTS.INVENTORY))
      if (!itemsResponse.ok) {
        throw new Error(`Failed to fetch items: ${itemsResponse.status} ${itemsResponse.statusText}`)
      }
      const itemsData = await itemsResponse.json()

      const complexResponse = await fetch(getApiUrl("/api/inventory/products"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isAssembledProduct: false }),
      })
      if (!complexResponse.ok) {
        throw new Error(`Failed to fetch complex items: ${complexResponse.status} ${complexResponse.statusText}`)
      }
      const complexData = await complexResponse.json()

      const availableForComponents = [
        ...itemsData, // Items with no components
        ...complexData.filter((item: InventoryItem) => item.components && item.components.length > 0), // Complex items with components
      ]

      setAvailableComponents(availableForComponents)
    } catch (error) {
      console.error("Failed to fetch available components:", error)
      toast({
        title: "Error",
        description: "Failed to fetch available components for dropdown",
        variant: "destructive",
      })
    }
  }

  const fetchProducts = async () => {
    try {
      const productsResponse = await fetch(getApiUrl("/api/inventory/products"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isAssembledProduct: true }),
      })
      if (!productsResponse.ok) {
        throw new Error(`Failed to fetch products: ${productsResponse.status} ${productsResponse.statusText}`)
      }
      const productsData = await productsResponse.json()

      const complexResponse = await fetch(getApiUrl("/api/inventory/products"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isAssembledProduct: false }),
      })
      if (!complexResponse.ok) {
        throw new Error(`Failed to fetch complex items: ${complexResponse.status} ${complexResponse.statusText}`)
      }
      const complexData = await complexResponse.json()

      const filteredProducts = showNonSupported
        ? productsData
        : productsData.filter((item: InventoryItem) => item.isSupported)

      const filteredComplex = showNonSupported
        ? complexData.filter((item: InventoryItem) => item.components && item.components.length > 0)
        : complexData.filter((item: InventoryItem) => item.isSupported && item.components && item.components.length > 0)

      setProducts(filteredProducts)
      setComplexItems(filteredComplex)
    } catch (error) {
      console.error("Failed to fetch products:", error)
      toast({
        title: "Error",
        description: "Failed to fetch products data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!loading) {
      fetchProducts()
    }
  }, [showNonSupported])

  const addComponentRow = () => {
    setNewProduct((prev) => ({
      ...prev,
      components: [...prev.components, { item: "", quantity: 1 }],
    }))
  }

  const updateComponent = (index: number, field: "item" | "quantity", value: string | number) => {
    setNewProduct((prev) => ({
      ...prev,
      components: prev.components.map((comp, i) => (i === index ? { ...comp, [field]: value } : comp)),
    }))
  }

  const removeComponent = (index: number) => {
    setNewProduct((prev) => ({
      ...prev,
      components: prev.components.filter((_, i) => i !== index),
    }))
  }

  const handleCreateProduct = async () => {
    if (!newProduct.itemName || !newProduct.sku || !newProduct.vendor) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch(getApiUrl(API_CONFIG.ENDPOINTS.INVENTORY), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newProduct,
          stock: 0,
        }),
      })

      if (response.ok) {
        await fetchProducts()
        setIsNewProductOpen(false)
        setNewProduct({
          itemName: "",
          sku: "",
          vendor: "v-armed", // Reset to default vendor
          link: "",
          isAssembledProduct: false,
          isSupported: true,
          components: [
            { item: "", quantity: 1 },
            { item: "", quantity: 1 },
          ], // Reset with 2 components
        })
        toast({
          title: "Success",
          description: "Product created successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create product",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading products...</div>
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Products Management</h1>
          <p className="text-muted-foreground">Manage your inventory items and assembly products</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={showNonSupported ? "default" : "outline"}
            onClick={() => setShowNonSupported(!showNonSupported)}
          >
            {showNonSupported ? "Hide Non-Supported" : "Show Non-Supported Items"}
          </Button>
          <Dialog open={isNewProductOpen} onOpenChange={setIsNewProductOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Product</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="itemName">Product Name *</Label>
                    <Input
                      id="itemName"
                      value={newProduct.itemName}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, itemName: e.target.value }))}
                      placeholder="Enter product name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="sku">SKU *</Label>
                    <Input
                      id="sku"
                      value={newProduct.sku}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, sku: e.target.value }))}
                      placeholder="Enter SKU"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="vendor">Vendor *</Label>
                    <Input
                      id="vendor"
                      value={newProduct.vendor}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, vendor: e.target.value }))}
                      placeholder="Enter vendor name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="link">Link (Optional)</Label>
                    <Input
                      id="link"
                      value={newProduct.link}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, link: e.target.value }))}
                      placeholder="Enter product link"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isAssembledProduct"
                    checked={newProduct.isAssembledProduct}
                    onCheckedChange={(checked) => setNewProduct((prev) => ({ ...prev, isAssembledProduct: !!checked }))}
                  />
                  <Label htmlFor="isAssembledProduct">This is an assembly product</Label>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <Label>Components</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addComponentRow}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Component
                    </Button>
                  </div>

                  {newProduct.components.map((component, index) => (
                    <div key={index} className="flex gap-2 items-end">
                      <div className="flex-1">
                        <Select value={component.item} onValueChange={(value) => updateComponent(index, "item", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select component" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableComponents.map((item) => (
                              <SelectItem key={item._id} value={item._id}>
                                {item.itemName}
                                {!item.isSupported && (
                                  <Badge variant="secondary" className="ml-2 text-xs">
                                    Non-supported
                                  </Badge>
                                )}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="w-24">
                        <Input
                          type="number"
                          min="1"
                          value={component.quantity}
                          onChange={(e) => updateComponent(index, "quantity", Number.parseInt(e.target.value) || 1)}
                          placeholder="Qty"
                        />
                      </div>
                      <Button type="button" variant="outline" size="sm" onClick={() => removeComponent(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end gap-2 pt-4">
                  <Button variant="outline" onClick={() => setIsNewProductOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateProduct}>Create Product</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search products by name, SKU, or vendor..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {filteredProducts.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            <h2 className="text-xl font-semibold">Products</h2>
            <Badge variant="secondary">{filteredProducts.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map((product) => (
              <Card key={product._id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <Link href={`/products/${product._id}`}>
                        <CardTitle className="text-lg hover:text-primary cursor-pointer transition-colors">
                          {product.itemName}
                        </CardTitle>
                      </Link>
                      <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {product.components && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Components:</span>
                      <span className="font-medium">{product.components.length}</span>
                    </div>
                  )}
                  <Link href={`/products/${product._id}`}>
                    <Button size="sm" className="w-full">
                      <Settings className="h-4 w-4 mr-2" />
                      Manage Product
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {filteredComplexItems.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            <h2 className="text-xl font-semibold">Complex Items</h2>
            <Badge variant="outline">{filteredComplexItems.length}</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredComplexItems.map((item) => (
              <Card key={item._id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <Link href={`/products/${item._id}`}>
                        <CardTitle className="text-lg hover:text-primary cursor-pointer transition-colors">
                          {item.itemName}
                        </CardTitle>
                      </Link>
                      <p className="text-sm text-muted-foreground">SKU: {item.sku}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Stock:</span>
                    <span className="font-medium">{item.stock}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Vendor:</span>
                    <span className="font-medium">{item.vendor}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Components:</span>
                    <span className="font-medium">{item.components?.length || 0}</span>
                  </div>
                  <Link href={`/products/${item._id}`}>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      <Settings className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {filteredProducts.length === 0 && filteredComplexItems.length === 0 && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Package className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No products found</h3>
            <p className="text-muted-foreground text-center">
              {searchTerm ? "Try adjusting your search terms" : "No products available"}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Minus, Save, X, Edit } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { getApiUrl, API_CONFIG } from "@/lib/config"
import { Label } from "@/components/ui/label"

interface InventoryItem {
  _id: string
  itemName: string
  sku: string
  stock: number
  vendor: string
  link?: string
  isAssembledProduct: boolean
  isSupported: boolean
  createdAt?: string
  updatedAt?: string
  components?: Array<{
    item: string
    quantity: number
  }>
}

interface StockAdjustment {
  _id: string
  quantity: string // Changed from number to string to prevent flickering
}

interface StockEdit {
  _id: string
  newStock: number
}

interface RowEdit {
  _id: string
  itemName: string
  sku: string
  vendor: string
  link: string
  isSupported: boolean
}

interface NewItem {
  itemName: string
  sku: string
  vendor: string
  link: string
  isSupported: boolean
}

type SortField = "itemName" | "sku" | "stock" | "vendor" | "createdAt" | "updatedAt"
type SortDirection = "asc" | "desc"

const StockAdjustmentDialog = ({
  isOpen,
  onOpenChange,
  isRemoval,
  stockAdjustments,
  inventory,
  updateStockAdjustment,
  removeStockAdjustmentRow,
  addStockAdjustmentRow,
  handleStockAdjustment,
}: {
  isOpen: boolean
  onOpenChange: (open: boolean) => void
  isRemoval: boolean
  stockAdjustments: StockAdjustment[]
  inventory: InventoryItem[]
  updateStockAdjustment: (index: number, field: keyof StockAdjustment, value: string | number) => void
  removeStockAdjustmentRow: (index: number) => void
  addStockAdjustmentRow: () => void
  handleStockAdjustment: (isRemoval: boolean) => void
}) => {
  const [validationErrors, setValidationErrors] = useState<{ [key: number]: { item?: boolean; quantity?: boolean } }>(
    {},
  )

  const validateRow = (index: number, adjustment: StockAdjustment) => {
    const errors: { item?: boolean; quantity?: boolean } = {}

    if (!adjustment._id) {
      errors.item = true
    }

    const quantity = Number(adjustment.quantity)
    if (!adjustment.quantity || quantity <= 0 || isNaN(quantity)) {
      errors.quantity = true
    }

    setValidationErrors((prev) => ({
      ...prev,
      [index]: errors,
    }))

    return Object.keys(errors).length === 0
  }

  const handleItemChange = (index: number, value: string) => {
    updateStockAdjustment(index, "_id", value)
    // Clear item error when user selects an item
    setValidationErrors((prev) => ({
      ...prev,
      [index]: { ...prev[index], item: false },
    }))
  }

  const handleQuantityChange = (index: number, value: string) => {
    updateStockAdjustment(index, "quantity", value)
    // Clear quantity error when user types
    setValidationErrors((prev) => ({
      ...prev,
      [index]: { ...prev[index], quantity: false },
    }))
  }

  const handleSubmit = () => {
    let hasErrors = false
    stockAdjustments.forEach((adjustment, index) => {
      if (!validateRow(index, adjustment)) {
        hasErrors = true
      }
    })

    if (!hasErrors) {
      handleStockAdjustment(isRemoval)
      setValidationErrors({}) // Clear errors on successful submit
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>{isRemoval ? "Remove from Stock" : "Add to Stock"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stockAdjustments.map((adjustment, index) => (
                <TableRow key={`adjustment-${index}`}>
                  <TableCell>
                    <div className="space-y-1">
                      <Select value={adjustment._id} onValueChange={(value) => handleItemChange(index, value)}>
                        <SelectTrigger
                          className={validationErrors[index]?.item ? "border-red-500 focus:border-red-500" : ""}
                        >
                          <SelectValue placeholder="Select item" />
                        </SelectTrigger>
                        <SelectContent>
                          {inventory.map((item) => (
                            <SelectItem key={item._id} value={item._id}>
                              {item.itemName} (Stock: {item.stock})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {validationErrors[index]?.item && <p className="text-xs text-red-500">Please select an item</p>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <Input
                        type="number"
                        min="1"
                        value={adjustment.quantity}
                        onChange={(e) => handleQuantityChange(index, e.target.value)}
                        placeholder="Enter quantity"
                        className={validationErrors[index]?.quantity ? "border-red-500 focus:border-red-500" : ""}
                      />
                      {validationErrors[index]?.quantity && (
                        <p className="text-xs text-red-500">Please enter a valid quantity</p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button variant="outline" size="sm" onClick={() => removeStockAdjustmentRow(index)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="flex gap-2">
            <Button onClick={addStockAdjustmentRow} variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Add Row
            </Button>
            <Button onClick={handleSubmit}>{isRemoval ? "Remove Stock" : "Add Stock"}</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default function InventoryDashboard() {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [stockEdits, setStockEdits] = useState<StockEdit[]>([])
  const [stockAdjustments, setStockAdjustments] = useState<StockAdjustment[]>([])
  const [isAddStockOpen, setIsAddStockOpen] = useState(false)
  const [isRemoveStockOpen, setIsRemoveStockOpen] = useState(false)
  const [isNewItemOpen, setIsNewItemOpen] = useState(false) // Add state for new item dialog
  const [loading, setLoading] = useState(true)
  const [sortField, setSortField] = useState<SortField>("itemName")
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc")
  const [isStockEditable, setIsStockEditable] = useState(false)
  const [showNonSupported, setShowNonSupported] = useState(false)
  const [editingRowId, setEditingRowId] = useState<string | null>(null)
  const [rowEdits, setRowEdits] = useState<{ [key: string]: RowEdit }>({})
  const [newItem, setNewItem] = useState<NewItem>({
    // Add state for new item form
    itemName: "",
    sku: "",
    vendor: "",
    link: "",
    isSupported: true,
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchInventory()
  }, [])

  const fetchInventory = async () => {
    try {
      const response = await fetch(getApiUrl(API_CONFIG.ENDPOINTS.INVENTORY))
      const data = await response.json()
      // Backend now filters items with no components, so no need to filter here
      setInventory(data)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch inventory data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleStockChange = (itemId: string, newStock: number) => {
    setStockEdits((prev) => {
      const existing = prev.find((edit) => edit._id === itemId)
      if (existing) {
        return prev.map((edit) => (edit._id === itemId ? { ...edit, newStock } : edit))
      } else {
        return [...prev, { _id: itemId, newStock }]
      }
    })
  }

  const getCurrentStock = (item: InventoryItem) => {
    const edit = stockEdits.find((edit) => edit._id === item._id)
    return edit ? edit.newStock : item.stock
  }

  const handleSaveAllChanges = async () => {
    if (stockEdits.length === 0) {
      toast({
        title: "No Changes",
        description: "No stock changes to save",
      })
      return
    }

    try {
      const response = await fetch(getApiUrl(`${API_CONFIG.ENDPOINTS.INVENTORY}/override-stock`), {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(stockEdits),
      })

      if (response.ok) {
        await fetchInventory()
        setStockEdits([])
        setIsStockEditable(false) // Reset editing mode after save
        toast({
          title: "Success",
          description: `Updated stock for ${stockEdits.length} items`,
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update stock",
        variant: "destructive",
      })
    }
  }

  const handleCancelAllChanges = () => {
    setStockEdits([])
    setIsStockEditable(false) // Reset editing mode on cancel
    toast({
      title: "Changes Cancelled",
      description: "All stock changes have been cancelled",
    })
  }

  const updateStockAdjustment = useCallback((index: number, field: keyof StockAdjustment, value: string | number) => {
    setStockAdjustments((prev) => {
      const updated = [...prev]
      updated[index] = { ...updated[index], [field]: value }
      return updated
    })
  }, [])

  const addStockAdjustmentRow = useCallback(() => {
    setStockAdjustments((prev) => [...prev, { _id: "", quantity: "" }])
  }, [])

  const removeStockAdjustmentRow = useCallback((index: number) => {
    setStockAdjustments((prev) => prev.filter((_, i) => i !== index))
  }, [])

  const handleStockAdjustment = async (isRemoval: boolean) => {
    const validAdjustments = stockAdjustments.filter((adj) => {
      const quantity = Number(adj.quantity)
      return adj._id && quantity > 0 && !isNaN(quantity)
    })

    if (validAdjustments.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one valid adjustment",
        variant: "destructive",
      })
      return
    }

    try {
      const adjustments = validAdjustments.map((adj) => ({
        _id: adj._id,
        amount: isRemoval ? -Number(adj.quantity) : Number(adj.quantity), // Parse to number here
      }))

      const response = await fetch(getApiUrl(`${API_CONFIG.ENDPOINTS.INVENTORY}/adjust-stock`), {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(adjustments),
      })

      if (response.ok) {
        await fetchInventory()
        setStockAdjustments([])
        setIsAddStockOpen(false)
        setIsRemoveStockOpen(false)
        toast({
          title: "Success",
          description: `Stock ${isRemoval ? "removed" : "added"} successfully`,
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to adjust stock",
        variant: "destructive",
      })
    }
  }

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const getSortedInventory = (items: InventoryItem[]) => {
    return [...items].sort((a, b) => {
      let aValue: any = a[sortField]
      let bValue: any = b[sortField]

      // Handle string comparison
      if (typeof aValue === "string" && typeof bValue === "string") {
        aValue = aValue.toLowerCase()
        bValue = bValue.toLowerCase()
      }

      // Handle date comparison
      if (sortField === "createdAt" || sortField === "updatedAt") {
        aValue = new Date(aValue || 0).getTime()
        bValue = new Date(bValue || 0).getTime()
      }

      if (aValue < bValue) return sortDirection === "asc" ? -1 : 1
      if (aValue > bValue) return sortDirection === "asc" ? 1 : -1
      return 0
    })
  }

  const getFilteredAndSortedInventory = () => {
    let filtered = inventory
    if (!showNonSupported) {
      filtered = inventory.filter((item) => item.isSupported)
    }
    return getSortedInventory(filtered)
  }

  const getItemRowClassName = (item: InventoryItem) => {
    let baseClass = "hover:bg-muted/50"

    if (!item.isSupported) {
      baseClass += " opacity-60 text-muted-foreground bg-gray-50/50 hover:bg-gray-100/50"
    } else if (item.isAssembledProduct) {
      // Products - subtle blue tint (only when supported)
      baseClass += " bg-blue-50/50 hover:bg-blue-100/50"
    } else if (item.components && item.components.length > 0) {
      // Complex items - subtle green tint (only when supported)
      baseClass += " bg-green-50/50 hover:bg-green-100/50"
    }

    return baseClass
  }

  const getItemTypeBadge = (item: InventoryItem) => {
    if (!item.isSupported) {
      return (
        <Badge variant="secondary" className="text-xs bg-gray-200 text-gray-600">
          Unsupported
        </Badge>
      )
    } else if (item.isAssembledProduct) {
      return (
        <Badge variant="default" className="text-xs bg-blue-100 text-blue-700">
          Product
        </Badge>
      )
    } else if (item.components && item.components.length > 0) {
      return (
        <Badge variant="default" className="text-xs bg-green-100 text-green-700">
          Complex
        </Badge>
      )
    }
    return (
      <Badge variant="outline" className="text-xs">
        Item
      </Badge>
    )
  }

  const handleRowFieldChange = (itemId: string, field: keyof RowEdit, value: string | boolean) => {
    setRowEdits((prev) => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        [field]: value,
      },
    }))
  }

  const getCurrentRowValues = (item: InventoryItem): RowEdit => {
    return (
      rowEdits[item._id] || {
        _id: item._id,
        itemName: item.itemName,
        sku: item.sku,
        vendor: item.vendor,
        link: item.link || "",
        isSupported: item.isSupported,
      }
    )
  }

  const handleRowDoubleClick = (item: InventoryItem) => {
    setEditingRowId(item._id)
    // Initialize row edit data
    setRowEdits((prev) => ({
      ...prev,
      [item._id]: {
        _id: item._id,
        itemName: item.itemName,
        sku: item.sku,
        vendor: item.vendor,
        link: item.link || "",
        isSupported: item.isSupported,
      },
    }))
  }

  const handleSaveRowChanges = async (itemId: string) => {
    const rowEdit = rowEdits[itemId]
    if (!rowEdit) return

    try {
      const response = await fetch(getApiUrl(`${API_CONFIG.ENDPOINTS.INVENTORY}/${itemId}`), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemName: rowEdit.itemName,
          sku: rowEdit.sku,
          vendor: rowEdit.vendor,
          link: rowEdit.link,
          isSupported: rowEdit.isSupported,
        }),
      })

      if (response.ok) {
        await fetchInventory()
        setEditingRowId(null)
        setRowEdits((prev) => {
          const updated = { ...prev }
          delete updated[itemId]
          return updated
        })
        toast({
          title: "Success",
          description: "Item updated successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update item",
        variant: "destructive",
      })
    }
  }

  const handleCancelRowChanges = (itemId: string) => {
    setEditingRowId(null)
    setRowEdits((prev) => {
      const updated = { ...prev }
      delete updated[itemId]
      return updated
    })
  }

  const handleCreateItem = async () => {
    // Add function to create new item
    if (!newItem.itemName || !newItem.sku || !newItem.vendor) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch(getApiUrl(API_CONFIG.ENDPOINTS.INVENTORY), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newItem,
          stock: 0,
          isAssembledProduct: false, // Always false for items
          components: undefined, // No components for items
        }),
      })

      if (response.ok) {
        await fetchInventory()
        setIsNewItemOpen(false)
        setNewItem({
          itemName: "",
          sku: "",
          vendor: "",
          link: "",
          isSupported: true,
        })
        toast({
          title: "Success",
          description: "Item created successfully",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create item",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  const displayedInventory = getFilteredAndSortedInventory()

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold">Inventory Dashboard</h1>
        <p className="text-muted-foreground">Manage your inventory stock levels and adjustments</p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold">Current Inventory</CardTitle>
            <div className="flex gap-2 items-center">
              <Button
                variant={showNonSupported ? "default" : "outline"}
                size="sm"
                onClick={() => setShowNonSupported(!showNonSupported)}
              >
                {showNonSupported ? "Hide Non-Supported" : "Show Non-Supported"}
              </Button>
              <Dialog open={isNewItemOpen} onOpenChange={setIsNewItemOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Add New Item</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="itemName">Item Name *</Label>
                      <Input
                        id="itemName"
                        value={newItem.itemName}
                        onChange={(e) => setNewItem((prev) => ({ ...prev, itemName: e.target.value }))}
                        placeholder="Enter item name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sku">SKU *</Label>
                      <Input
                        id="sku"
                        value={newItem.sku}
                        onChange={(e) => setNewItem((prev) => ({ ...prev, sku: e.target.value }))}
                        placeholder="Enter SKU"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="vendor">Vendor *</Label>
                      <Input
                        id="vendor"
                        value={newItem.vendor}
                        onChange={(e) => setNewItem((prev) => ({ ...prev, vendor: e.target.value }))}
                        placeholder="Enter vendor name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="link">Link (Optional)</Label>
                      <Input
                        id="link"
                        value={newItem.link}
                        onChange={(e) => setNewItem((prev) => ({ ...prev, link: e.target.value }))}
                        placeholder="Enter item link"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isSupported"
                        checked={newItem.isSupported}
                        onCheckedChange={(checked) => setNewItem((prev) => ({ ...prev, isSupported: !!checked }))}
                      />
                      <Label htmlFor="isSupported">This item is supported</Label>
                    </div>
                    <div className="flex justify-end gap-2 pt-4">
                      <Button variant="outline" onClick={() => setIsNewItemOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleCreateItem}>Create Item</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              {!isStockEditable && (
                <Button variant="outline" size="sm" onClick={() => setIsStockEditable(true)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Stocks
                </Button>
              )}
              {isStockEditable && (
                <>
                  <Button variant="outline" onClick={handleCancelAllChanges}>
                    Cancel Changes
                  </Button>
                  <Button onClick={handleSaveAllChanges}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  className="cursor-pointer hover:bg-muted/50 select-none"
                  onClick={() => handleSort("itemName")}
                >
                  Item Name
                </TableHead>
                <TableHead className="cursor-pointer hover:bg-muted/50 select-none" onClick={() => handleSort("sku")}>
                  SKU
                </TableHead>
                <TableHead className="cursor-pointer hover:bg-muted/50 select-none" onClick={() => handleSort("stock")}>
                  Stock
                </TableHead>
                <TableHead
                  className="cursor-pointer hover:bg-muted/50 select-none"
                  onClick={() => handleSort("vendor")}
                >
                  Vendor
                </TableHead>
                <TableHead>Supported</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayedInventory.map((item) => {
                const isEditing = editingRowId === item._id
                const currentValues = getCurrentRowValues(item)

                return (
                  <TableRow
                    key={item._id}
                    className={getItemRowClassName(item)}
                    onDoubleClick={() => !isEditing && handleRowDoubleClick(item)}
                    style={{ cursor: !isEditing ? "pointer" : "default" }}
                  >
                    <TableCell className="font-medium">
                      {isEditing ? (
                        <Input
                          value={currentValues.itemName}
                          onChange={(e) => handleRowFieldChange(item._id, "itemName", e.target.value)}
                          className="w-full"
                        />
                      ) : (
                        item.itemName
                      )}
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Input
                          value={currentValues.sku}
                          onChange={(e) => handleRowFieldChange(item._id, "sku", e.target.value)}
                          className="w-full"
                        />
                      ) : (
                        item.sku
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {isStockEditable ? (
                          <Input
                            type="number"
                            value={getCurrentStock(item)}
                            onChange={(e) => handleStockChange(item._id, Number.parseInt(e.target.value) || 0)}
                            className="w-20"
                            min="0"
                          />
                        ) : (
                          <span className="w-20 text-center">{getCurrentStock(item)}</span>
                        )}
                        {getCurrentStock(item) <= 10 && (
                          <Badge variant="destructive" className="text-xs">
                            Low
                          </Badge>
                        )}
                        {stockEdits.find((edit) => edit._id === item._id) && (
                          <Badge variant="secondary" className="text-xs">
                            Modified
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Input
                          value={currentValues.vendor}
                          onChange={(e) => handleRowFieldChange(item._id, "vendor", e.target.value)}
                          className="w-full"
                        />
                      ) : (
                        item.vendor
                      )}
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <Checkbox
                          checked={currentValues.isSupported}
                          onCheckedChange={(checked) =>
                            handleRowFieldChange(item._id, "isSupported", checked as boolean)
                          }
                        />
                      ) : (
                        <Checkbox checked={item.isSupported} disabled />
                      )}
                    </TableCell>
                    <TableCell>
                      {isEditing ? (
                        <div className="flex gap-2">
                          <Button size="sm" onClick={() => handleSaveRowChanges(item._id)}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => handleCancelRowChanges(item._id)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="ghost" onClick={() => handleRowDoubleClick(item)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Dialog open={isAddStockOpen} onOpenChange={setIsAddStockOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setStockAdjustments([{ _id: "", quantity: "" }])}>
              <Plus className="h-4 w-4 mr-2" />
              Add to Stock
            </Button>
          </DialogTrigger>
        </Dialog>

        <Dialog open={isRemoveStockOpen} onOpenChange={setIsRemoveStockOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" onClick={() => setStockAdjustments([{ _id: "", quantity: "" }])}>
              <Minus className="h-4 w-4 mr-2" />
              Remove from Stock
            </Button>
          </DialogTrigger>
        </Dialog>

        <StockAdjustmentDialog
          isOpen={isAddStockOpen}
          onOpenChange={setIsAddStockOpen}
          isRemoval={false}
          stockAdjustments={stockAdjustments}
          inventory={inventory}
          updateStockAdjustment={updateStockAdjustment}
          removeStockAdjustmentRow={removeStockAdjustmentRow}
          addStockAdjustmentRow={addStockAdjustmentRow}
          handleStockAdjustment={handleStockAdjustment}
        />

        <StockAdjustmentDialog
          isOpen={isRemoveStockOpen}
          onOpenChange={setIsRemoveStockOpen}
          isRemoval={true}
          stockAdjustments={stockAdjustments}
          inventory={inventory}
          updateStockAdjustment={updateStockAdjustment}
          removeStockAdjustmentRow={removeStockAdjustmentRow}
          addStockAdjustmentRow={addStockAdjustmentRow}
          handleStockAdjustment={handleStockAdjustment}
        />
      </div>
    </div>
  )
}

const SortIcon = ({ field }: { field: SortField }) => {}

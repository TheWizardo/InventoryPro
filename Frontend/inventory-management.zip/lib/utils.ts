import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generateEmployeeColor(employeeId: string): string {
  // Create a simple hash from the employee ID
  let hash = 0
  for (let i = 0; i < employeeId.length; i++) {
    const char = employeeId.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32-bit integer
  }

  // Convert to positive number
  const positiveHash = Math.abs(hash)

  // Generate HSL values from hash
  const hue = (positiveHash * 1.5) % 360 // Full range 0-360
  const saturation = 0.5 + (positiveHash % 50) / 100 // Range 0.5-1.0
  const luminosity = 0.5 + ((positiveHash >> 8) % 50) / 100 // Range 0.5-1.0

  return `hsl(${hue}, ${Math.round(saturation * 100)}%, ${Math.round(luminosity * 100)}%)`
}
